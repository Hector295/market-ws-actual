{{/*
Expand the name of the chart.
*/}}
{{- define "genieacs.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "genieacs.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "genieacs.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "genieacs.labels" -}}
helm.sh/chart: {{ include "genieacs.chart" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
cwmp Selector labels
*/}}
{{- define "genieacs-cwmp.selectorLabels" -}}
app.kubernetes.io/name: {{ include "genieacs.name" . }}-cwmp
app.kubernetes.io/instance: {{ .Release.Name }}-cwmp
{{- end }}

{{/*
fs Selector labels
*/}}
{{- define "genieacs-fs.selectorLabels" -}}
app.kubernetes.io/name: {{ include "genieacs.name" . }}-fs
app.kubernetes.io/instance: {{ .Release.Name }}-fs
{{- end }}

{{/*
ui Selector labels
*/}}
{{- define "genieacs-ui.selectorLabels" -}}
app.kubernetes.io/name: {{ include "genieacs.name" . }}-ui
app.kubernetes.io/instance: {{ .Release.Name }}-ui
{{- end }}

{{/*
nbi Selector labels
*/}}
{{- define "genieacs-nbi.selectorLabels" -}}
app.kubernetes.io/name: {{ include "genieacs.name" . }}-nbi
app.kubernetes.io/instance: {{ .Release.Name }}-nbi
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "genieacs.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "genieacs.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}
